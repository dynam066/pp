-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2019 at 07:53 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerece`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `getcat` (IN `cid` INT)  SELECT * FROM categories WHERE cat_id=cid$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` varchar(300) NOT NULL,
  `admin_password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'admin', 'admin@gmail.com', '25f9e794323b453885f5181f1b624d0b');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(100) NOT NULL,
  `brand_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'Louis Vuitton'),
(2, 'Gucci'),
(3, 'Versace'),
(4, 'Calvin Klein'),
(5, 'Champion'),
(6, 'All Top Brands');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `qty` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `qty`) VALUES
(6, 26, '::1', 4, 1),
(9, 10, '::1', 7, 1),
(10, 11, '::1', 7, 1),
(11, 45, '::1', 7, 1),
(44, 5, '::1', 3, 0),
(46, 2, '::1', 3, 0),
(48, 72, '::1', 3, 0),
(49, 60, '::1', 8, 1),
(50, 61, '::1', 8, 1),
(51, 1, '::1', 8, 1),
(52, 5, '::1', 9, 1),
(53, 2, '::1', 14, 1),
(54, 3, '::1', 14, 1),
(55, 5, '::1', 14, 1),
(56, 1, '::1', 9, 1),
(57, 2, '::1', 9, 1),
(71, 61, '127.0.0.1', -1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(100) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Shirts'),
(2, 'T-Shirts'),
(3, 'Kurtas'),
(4, 'Trousers'),
(5, 'Jeans'),
(6, 'Hoodies'),
(7, 'Jackets'),
(8, 'Dhoti'),
(9, 'Shorts'),
(10, 'Suits '),
(11, 'Coats &<br> Bathrobes'),
(12, 'Sweaters'),
(13, 'InnerWear');



-- --------------------------------------------------------

--
-- Table structure for table `email_info`
--

CREATE TABLE `email_info` (
  `email_id` int(100) NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email_info`
--

INSERT INTO `email_info` (`email_id`, `email`) VALUES
(3, 'admin@gmail.com'),
(4, 'felbinjo@gmail.com'),
(5, 'binilv@gmail.com'),
(6, 'asishjy@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(12) NOT NULL,
  `qty` int(11) NOT NULL,
  `trx_id` varchar(255) NOT NULL,
  `p_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_id`, `qty`, `trx_id`, `p_status`) VALUES
(1, 12, 7, 1, '07M47684BS5725041', 'Completed'),
(2, 14, 2, 1, '07M47684BS5725041', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `orders_info`
--

CREATE TABLE `orders_info` (
  `order_id` int(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` int(10) NOT NULL,
  `cardname` varchar(255) NOT NULL,
  `cardnumber` varchar(20) NOT NULL,
  `expdate` varchar(255) NOT NULL,
  `prod_count` int(15) DEFAULT NULL,
  `total_amt` int(15) DEFAULT NULL,
  `cvv` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders_info`
--

INSERT INTO `orders_info` (`order_id`, `user_id`, `f_name`, `email`, `address`, `city`, `state`, `zip`, `cardname`, `cardnumber`, `expdate`, `prod_count`, `total_amt`, `cvv`) VALUES
(1, 12, 'binil', 'binilv@gmail.com', '4515 Pointe Lane', 'HollyWood' , 'Florida', 33020, 'bvthz', '4321 2345 6788 7654', '12/90', 3, 77000, 1234);

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `order_pro_id` int(10) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(15) DEFAULT NULL,
  `amt` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_products`
--

INSERT INTO `order_products` (`order_pro_id`, `order_id`, `product_id`, `qty`, `amt`) VALUES
(73, 1, 1, 1, 5000),
(74, 1, 4, 2, 64000),
(75, 1, 8, 1, 40000);

-- ---------------------------------------------------------

-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_cat` int(100) NOT NULL,
  `product_brand` int(100) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES
(1, 1, 6, 'PARADA--Double Match Poplin Shirt', 5000, 'Double Match Poplin Shirt', 'UCS406_1ZVH_F0010_S_212_SLF.png', 'PARADA-Shirt'),
(2, 1, 1, 'LV--Multicolor Watercolor Shirt', 4000, 'Multicolor Watercolor Shirt', 'louis-vuitton-multicolor-watercolor-shirt-ready-to-wear--HLS02WBT3MU1_PM2_Front view.png', 'Louis Vuitton(LV)-Shirt'),
(3, 1, 1, 'LV--DNA Shirt', 6000, 'DNA shirt', 'louis-vuitton-dna-shirt-ready-to-wear--HHS20WORS644_PM2_Front.png', 'Louis Vuitton(LV)-DNA shirt'),
(4, 1, 2, 'Gucci--Nylon Shirt', 4000, 'Nylon Shirt', 'nylon-shirt.jpg', 'Light-Nylon Shirt'),
(5, 1, 6, 'Shiny Gold Metallic Shirt', 2000, 'Shiny Gold Metallic Shirt', 'shiny-gold-metallic-shirt-men-2018-fashion.jpg', 'Gold Shirt'),
(6, 1, 2, 'Gucci--Designer Shirt', 3000, 'Gucci-Designer-Shirt', 'Gucci-Designer-Shirt-For-Men.jpg', 'Gucci-Shirt '),
(7, 1, 6, 'Metallic Golden Shimmering Two Tone Long Sleeve Club Shirt', 3000, 'Golden Shimmering Two Tone Long Sleeve Club Shirt', '7154t+qOZ3L._UL1000_.jpg', 'Brand Casual Shirt'),
(8, 1, 6, 'Fashion-Mesh-Transparent Shirt', 5000, 'Mesh-Transparent Shirts', 'INCERUN-Fashion-Mesh-Shirts-Mens-Long-Sleeve-Turn-Down-Collar-Camisa-Sheer-Shirt-Plaid-Transparent-Sexy.jpg', 'Transparent Shirt'),
(9, 1, 2, 'Gucci--Full Sleeves Designer Shirts', 2000, 'Full Sleeves Designer Shirts', 'Image-2021-09-27-at-1.32.47-PM-1.jpeg', 'Gucci Full Sleeves Designer Shirts'),
(10, 1, 2, 'Gucci--logo star print shirt', 2000, 'logo star print shirt', '13509872_15972236_1000.png', 'Star Print Shirt'),
(11, 1, 2, 'Gucci--GG Harness Bowling shirt', 2500, 'GG Harness Bowling shirt', '14204086_20769180_10.png', 'Harness Bowling shirt'),
(12, 1, 2, 'Gucci--Embroidered-detail Shirt', 1999, 'Embroidered-detail Shirt', '15088031_26369064_1000.png', 'Embroidered Shirt'),
(13, 1, 2, 'Gucci--Striped Double G Cotton Shirt', 1800, 'Cotton Shirt', '17768812_37312109_100.png', 'Cotton Shirt'),
(14, 1, 2, 'Gucci--Floral print Silk foulard Shirt', 3400, 'Floral print Silk foulard Shirt', '12596552_master.jpg', 'Floral print Silk foulard Shirt'),
(15, 1, 2, 'Gucci--Logo Embellished Bowling shirt', 2999, 'Embellished Bowling shirt in White', '9632068_88.png', 'Embellished Bowling shirt'),
(16, 1, 2, 'Gucci-- Gg Psychedelic Print Bowling shirt', 3800, 'Psychedelic Print Bowling shirt', '15160387_25880659_1.png', 'Psychedelic Print Bowling shirt'),
(17, 1, 3, 'Versace--Barocco Mosaic-print silk shirt', 9900, 'Barocco Mosaic-print silk shirt', 'unnad.jpg', 'Barocco Mosaic-print silk shirt'),
(19, 1, 3, 'Versace--Leopard-pattern beaded Shirt', 9000, 'Leopard-pattern beaded Shirt', '15363173_28488919_1000.png', 'Leopard-pattern Shirt'),
(20, 1, 3, 'Versace--Greca-print cotton Shirt', 3600, 'Greca print shirt', '17334071_36618300_10.png', 'cotton shirt '),
(21, 1, 3, 'versace--Medusa Renaissance print Shirt', 8000, 'Medusa Renaissance print Shirt', 'versace.png', 'Medusa Renaissance print Shirt'),
(22, 1, 3, 'versace--Medusa Renaissance kids print silk Shirt ', 9999, 'kids print silk shirt', 'kidsmedusa.png', 'kids print Silk shirt'),
(23, 1, 3, 'versace--Baroque-print trimmed cotton Shirt', 7900, 'Baroque print cotton shirt', 'baroque.png', 'baroque print cotton shirt'),
(24, 1, 3, 'Versace--Baroccoflage print cotton Shirt', 5000, 'Baroccoflage cotton shirt', 'baroccoflage.png', 'baroccoflage cotton shirt'),
(25, 1, 4, 'CK--stylish party wear Shirt', 2500, 'ck party wear shirt', 'IMG-20210108-WA0050.jpg', 'party wear shirt'),
(27, 1, 4, 'CK--red white combination shirt', 2300, 'ck shirts', 'download.png', 'ck shirt'),
(32, 1, 4, 'CK--cotton-men-printed Multicolor Shirt', 2500, 'ck Multicolor shirt', 'product-jpeg-500x500.jpg', 'ck cotton shirt'),
(33, 1, 6, 'MSGM--Trees print short sleeve Shirt', 3000, 'grafity printed shirt', '17161708_347588.png', 'MSGM shirt'),
(34, 1, 6, 'PS_Paul Smith--Floral camp collar Shirt', 2000, 'ps shirt', '16827555_334.png', 'paul smith shirt'),
(35, 1, 6, 'United Colors of Benetton--Designer Shirt', 2000, 'UCB shirt', '1ca98ab36ccd02c4f3c0bdefc8e2b48e.jpg', 'designer shirt'),
(36, 1, 6, 'ZARA--white designer shirt', 1999, 'designer shirt', '79ebae285662c4e684e7e0851f5f9338.jpg', 'zara shirt'),
(37, 1, 6, 'Pepe jeans--Stirpe designer shirt', 1600, 'pepejeans shirt', '41f06c368ceb1039e1b0a11d7bb8310c.jpg', 'pepe designer shirt'),
(38, 1, 6, 'Mufti Mustard Yellow Checks Full Sleeves Relaxed Shirt', 2579, 'Mufti Mustard Yellow Checks Full Sleeves Relaxed Shirt', 'product08.png', 'Mufti Mustard Yellow Checks Full Sleeves Relaxed Shirt'),
(255, 4, 6, 'Kids blue dress', 300, 'blue dress', '1543993724_pg4.jpg', 'kids blue dress'),
(255, 4, 6, 'Kids blue dress', 300, 'blue dress', '1543993724_pg4.jpg', 'kids blue dress'),
(255, 4, 6, 'Kids blue dress', 300, 'blue dress', '1543993724_pg4.jpg', 'kids blue dress'),
(255, 4, 6, 'Kids blue dress', 300, 'blue dress', '1543993724_pg4.jpg', 'kids blue dress'),
(255, 4, 6, 'Kids blue dress', 300, 'blue dress', '1543993724_pg4.jpg', 'kids blue dress'),
(255, 4, 6, 'Kids blue dress', 300, 'blue dress', '1543993724_pg4.jpg', 'kids blue dress'),
(255, 4, 6, 'Kids blue dress', 300, 'blue dress', '1543993724_pg4.jpg', 'kids blue dress'),
(255, 4, 6, 'Kids blue dress', 300, 'blue dress', '1543993724_pg4.jpg', 'kids blue dress'),

(38, 2, 6, 'Billionaire--Black-Graphic-Printed-Polo T-Shirt', 1000, 'Black-Graphic-Printed-Polo', 'Black-Graphic-Printed-Polo.jpg', 'Black-Graphic-Printed-Polo'),
(39, 2, 3, 'versace--Henley-Neck and V-Neck-T Shirts', 800, 'Henley-Neck-and-V-Neck-Versace-T Shirts', 'Henley-Neck-and-V-Neck-Versace-T Shirts.jpg', 'Henley-Neck-and-V-Neck-Versace-T Shirts'),
(40, 2, 1, 'LV--brown and white T-Shirt', 700, 'Formal T-Shirt', 'ff902e7d81a87df866c84b9ddd2958d3.jpg', 'lv T-Shirt'),
(45, 2, 1, 'LV--brown and blue polo T-Shirt', 600, 'polo T-Shirt', 'd33da95afc8454180ccf5a1221551790.jpg', 'lv polo T-Shirt'),
(46, 2, 1, 'LV--white printed T-Shirt', 500, 'T-Shirt', 'gfy3hvii9s2.jpg', 'white T-Shirt'),
(47, 2, 2, 'Gucci--bee printed T-Shirt with logo', 900, 'Gucci-Designer-T-Shirt', 'd02f5ad0ca37eada6051c5103903f84d.jpg', 'bee printed T-Shirt'),
(48, 2, 2, 'Gucci--oversized cotton red T-Shirt', 750, 'Gucci T-Shirt', 'a3bf4e345a52f6cb70e521f78f667753.jpg', 'red T-Shirt'),
(49, 2, 6, 'Being-Human--Round-Half-Sleeves-T-Shirt', 820, 'Being-Human-Round-Half-Sleeves-T-Shirt', 'Being-Human-Round-Half-Sleeves-T-Shirt-For-Men-White-3.jpg', 'Being-Human-Round-Half-Sleeves-T-Shirt'),
(50, 2, 2, 'Gucci--oversized cotton silk T-Shirt with logo', 1500, 'cotton T-shirts', '0ee83cf6e6a0266d044f24aef2d7b740.jpg', 'cotton T-Shirt with logo'),
(51, 2, 6, 'Hip-Hop-Half-Sleeve-Casual-Harajuku-Fashion-Patchwork-T-Shirt', 800, 'Hip-Hop-T-Shirt', 'Hip-Hop-T-Shirt-Half-Sleeve-Mens-Casual-Harajuku-T-Shirts-Fashion-Patchwork-T-Shirt-Black.jpg_640x640.jpg', 'Hip-Hop-T-Shirt-Half-Sleeve-Mens-Casual-Harajuku-T-Shirts-Fashion-Patchwork-T-Shirt'),
(52, 2, 6, 'Harajuku-Streetwear-Fashions-Funny-Half-Sleeve-Hip-Hop-T-Shirt', 453, 'T-Shirt-Men-Harajuku-Streetwear-Fashions-Funny-Half-Sleeve-Hip-Hop-T-Shirt', 'T-Shirt-Men-Harajuku-Streetwear-Fashions-Funny-Tshirt-Men-Half-Sleeve-Hip-Hop-T-Shirt-Men.jpg', 'T-Shirt-Men-Harajuku-Streetwear-Fashions-Funny-Tshirt-Men-Half-Sleeve-Hip-Hop-T-Shirt'),
(53, 2, 6, 'Lacoste--Cotton-Round-Neck-Half-Sleeves-T-Shirt-Dark-Brown', 760, 'Cotton-Round-Neck-Half-Sleeves-T-Shirt-Dark-Brown', '100-Cotton-Round-Neck-Half-Sleeves-Lacoste-Men-T-Shirt-By-Ganesh-Fashion-Dark-Brown.jpg', 'Cotton-Round-Neck-Half-Sleeves-T-Shirt-Dark-Brown'),
(54, 2, 6, 'Tommy-Hilfiger--Cotton-round-neck-T-Shirt', 550, 'Tommy-T-shirts', 'men-branded-t-shirt-500x500.jpg', 'cotton T-shirt'),
(55, 2, 6, 'Lacoste--black polo T-Shirt', 899, 'black polo T-Shirt', 'mens-polo-t-shirt-500x500.jpeg', 'black polo T-Shirt'),
(56, 2, 6, 'Chanel--logo-v-neck T-Shirt', 699, 'T-shirts', 'chanel-logo-v-neck-t-shirt-1.jpg', 'white T-Shirt'),
(57, 2, 6, 'Armani--logo-white T-Shirts', 590, 'T-shirts', 'Armani-TShirts-for-MEN-9109091_800x800.jpg', 'T-shirts'),
(58, 2, 6, 'Armani--white polo T-Shirt with logo', 700, 'T-shirts', 'd530f7578a24e7f1fa55d73d10d387a4.jpg', 'polo T-Shirt'),
(95, 2, 5, 'Champion Rainbow Logo T-Shirt', 499, 'Champion Rainbow Logo T-Shirt', 'Champion Rainbow Logo T-Shirt.jpg', 'Champion Rainbow Logo T-Shirt'),
(96, 2, 5, 'Champion Heritage All Over Print T-Shirt', 699, 'Heritage All Over Print T-Shirt', 'Heritage All Over Print T-Shirt.jpg', 'Heritage All Over Print T-Shirt'),
(97, 2, 5, 'Champion Over Script T-Shirt', 580, 'Over Script T-Shirt', 'Over Script T-Shirt..jpg', 'Over Script T-Shirt'),
(98, 2, 5, 'Champion white-T-_shirt', 450, 'Champion-t-_shirt', '5f29272893d16Champion-t-_shirt-305381-ww001_-1_Front_website.jpg', 'Champion-t-_shirt'),
(99, 2, 5, 'Champion-Apparel-Tshirt', 400, 'Champion-Apparel-Tshirt', '161-Champion-Apparel-Tshirt.jpg', 'Champion-Apparel-Tshirt'),
(255, 4, 6, 'Kids blue dress', 300, 'blue dress', '1543993724_pg4.jpg', 'kids blue dress'),
(255, 4, 6, 'Kids blue dress', 300, 'blue dress', '1543993724_pg4.jpg', 'kids blue dress'),
(255, 4, 6, 'Kids blue dress', 300, 'blue dress', '1543993724_pg4.jpg', 'kids blue dress'),
(255, 4, 6, 'Kids blue dress', 300, 'blue dress', '1543993724_pg4.jpg', 'kids blue dress'),


(59, 3, 6, 'very me Men Printed Polycotton Straight Kurta-Dark Blue', 2000, 'very me Men Printed Polycotton Straight Kurta', '(very me Men Printed Polycotton Straight Kurta  (Dark Blue)).jpeg', '(very me Men Printed Polycotton Straight Kurta'),
(60, 3, 6, 'Route-by-pantaloons-men-beige-woven-design-straight-kurta', 3000, 'route-by-pantaloons-men-beige-woven-design-straight-kurta', '1a34h-indus-route-by-pantaloons-men-beige-woven-design-straight-kurta_500x500_0.jpg', 'indus-route-by-pantaloons-kurta'),
(61, 3, 6, 'rg-designers-Men-Paisley-Cotton-Blend-Straight-Kurta-blue', 1999, 'blue-rg-designers-Men-Paisley-Cotton-Blend-Straight-Kurta', 'blue-rg-designers-Men-Paisley-Cotton-Blend-Straight-Kurta.jpeg', 'blue-rg-designers-Men-Paisley-Cotton-Blend-Straight-Kurta'),
(62, 3, 6, 'Classic Assymteric Blue Waist Coat Set', 1000, 'Classic Assymteric Blue Waist Coat Set', 'ClassicAssymtericBlueWaistCoatSet.jpg', 'ClassicAssymtericBlueWaistCoatSet'),
(63, 3, 6, 'Cotton-Casual-Wear-Men-Plain-White-Punjabi-Kurta-Pajama-Set', 3050, 'Cotton-Casual-Wear-Men-Plain-White-Punjabi-Kurta-Pajama-Set', 'Cotton-Casual-Wear-Men-Plain-White-Punjabi-Kurta-Pajama-Set.jpg', 'Cotton-Casual-Wear-Men-Plain-White-Punjabi-Kurta-Pajama-Set'),
(64, 3, 6, 'fabindia--blue-cotton-dobby-slim-fit-long-kurta', 2860, 'fabindia--blue-cotton-dobby-slim-fit-long-kurta', 'fabindia--blue-cotton-dobby-slim-fit-long-kurta.jpg', 'fabindia--blue-cotton-dobby-slim-fit-long-kurta'),
(65, 3, 6, 'peter-england-Men-Navy-Kurta-Pyjama-And-Waistcoat', 4444, 'peter-england-Men-Navy-Kurta-Pyjama-And-Waistcoat', 'peter-england-Men-Navy-Kurta-Pyjama-And-Waistcoat.jpg', 'peter-england-Men-Navy-Kurta-Pyjama-And-Waistcoat'),
(66, 3, 6, 'Sojanya-Silk-Blend-Gold--Kurta-Churidaar-Pyjama-&-Green-Sherwani-Jacket-Set', 4800, 'Sojanya-Silk-Blend-Gold--Kurta', 'Sojanya-(Since 1958),-Mens-Silk-Blend-Gold--Kurta-Churidaar-Pyjama-&-Green-Sherwani-Jacket-Set.jpg', 'Sojanya-Silk-Blend-Gold-Kurta'),
(67, 3, 6, 'fabindia--teal-blue-kurta.jpg', 3060, 'fabindia--teal-blue-kurta', 'fabindia--teal-blue-kurta.jpg', 'fabindia--teal-blue-kurta'),
(68, 3, 6, 'freehand-men-beige-solid-straight-pleated-kurta', 1150, 'freehand-men-beige-solid-straight-pleated-kurta', 'freehand-men-beige-solid-straight-pleated-kurta.jpg', 'freehand-men-beige-solid-straight-pleated-kurta'),
(69, 3, 6, 'Freehand-Mens-Cotton-Kurta-Pyjama', 2200, 'Freehand-Mens-Cotton-Kurta-Pyjama', 'Freehand-Mens-Cotton-Kurta-Pyjama.jpg', 'Freehand-Mens-Cotton-Kurta-Pyjama'),
(70, 3, 6, 'indus-route--Rust-Patterned-Kurta', 3999, 'indus-route--Rust-Patterned-Kurta', 'indus-route--Rust-Patterned-Kurta.jpeg', 'indus-route--Rust-Patterned-Kurta'),
(71, 3, 6, 'svanik-Colourblock-Short-Kurta-with-Roll-Up-Tabs', 2000, 'svanik-Colourblock-Short-Kurta-with-Roll-Up-Tabs', 'svanik-Colourblock-Short-Kurta-with-Roll-Up-Tabs.png', 'svanik-Colourblock-Short-Kurta-with-Roll-Up-Tabs'),
(72, 2, 6, 'white-Round-Full-Sleeves-T-Shirt', 500, 'T-Shirt', 'product02.png', 'T-shirts'),
(73, 3, 6, 'Manyavar-Floral-Print-Full-Sleeves-Side-Opening-Casual-Wear-Kurta', 3500, 'Manyavar-Floral-Print-Full-Sleeves-Side-Opening-Casual-Wear-Kurta', 'Manyavar-Floral-Print-Full-Sleeves-Side-Opening-Casual-Wear-Kurta.jpg', 'Manyavar-Floral-Print-Full-Sleeves-Side-Opening-Casual-Wear-Kurta'),
(74, 3, 6, 'Manyavar-Printed-Side-Button-Kurta', 1500, 'Manyavar-Printed-Side-Button-Kurta', 'Manyavar-Printed-Side-Button-Kurta.jpg', 'Manyavar-Printed-Side-Button-Kurta'),
(75, 3, 6, 'peter-england-Men-Cream-Kurta-And-Pyjama', 5500, 'peter-england-Men-Cream-Kurta-And-Pyjama', 'peter-england-Men-Cream-Kurta-And-Pyjama.jpg', 'peter-england-Men-Cream-Kurta-And-Pyjama'),
(76, 3, 6, 'Sojanya-Silk-Blend-Black-Kurta-Pyjama-&-Sea-Green-Nehrujacket-Set', 4500, 'Sojanya-Silk-Blend-Black-Kurta', 'Sojanya-(Since 1958)-Mens-Silk-Blend-Black-Kurta-Pyjama-&-Sea-Green-Nehrujacket-Set.jpg', 'Sojanya-(Since 1958)-Mens-Silk-Blend-Black-Kurta'),
(77, 3, 6, 'SVANIK-Red-&-Orange-Floral-Print-Kurta', 1499, 'SVANIK-Red-&-Orange-Floral-Print-Kurta', 'SVANIK-Red-&-Orange-Floral-Print-Kurta-for-Men.jpg', 'SVANIK-Red-&-Orange-Floral-Print-Kurta'),
(80, 3, 6, 'the-indian-garage-Checked-Slim-Fit-Kurta-with-Mandarin-Collar', 1234, 'the-indian-garage-Checked-Slim-Fit-Kurta', 'the-indian-garage-Checked-Slim-Fit-Kurta-with-Mandarin-Collar.png', 'the-indian-garage-Checked-Slim-Fit-Kurta-with-Mandarin-Collar'),
(81, 3, 6, 'The-Indian-Garage-Co-Men-Kurta', 1000, 'The-Indian-Garage-Co-Men-Kurta', 'The-Indian-Garage-Co-Men-Kurta.jpg', 'The-Indian-Garage-Co-Men-Kurta'),

(82, 4, 3, 'Versace--LOGO BAROQUE PRINT VELVET TRACKPANTS', 1000, 'LOGO BAROQUE PRINT VELVET TRACKPANTS', 'LOGO BAROQUE PRINT VELVET TRACKPANTS.jpg', 'LOGO BAROQUE PRINT VELVET TRACKPANTS'),
(83, 4, 3, 'versace Mens Activewear Joggers', 1200, 'versace Mens Activewear Joggers', 'versace Mens Activewear Joggers.jpg', 'versace Mens Activewear Joggers'),
(84, 4, 3, 'versace Medusa Renaissance print sweatpants', 900, 'versace Medusa Renaissance print sweatpants', 'versace Medusa Renaissance print sweatpants.jpg', 'versace Medusa Renaissance print sweatpants'),
(85, 4, 3, 'Versace Jeans Couture jogging trousers with baroque print', 1100, 'Versace Jeans Couture jogging trousers with baroque print', 'Versace Jeans Couture jogging trousers with baroque print.jpg', 'Versace Jeans Couture jogging trousers with baroque print'),
(86, 2, 3, 'versace Baroccoflage stretch-cotton T-shirt', 800, 'versace Baroccoflage stretch-cotton T-shirt', 'versace Baroccoflage stretch-cotton T-shirt.jpg', 'versace Baroccoflage stretch-cotton T-shirt'),
(87, 4, 3, 'versace Solid Men Yellow Track Pants', 700, 'versace Solid Men Yellow Track Pants', 'versace Solid Men Yellow Track Pants.jpeg', 'versace Solid Men Yellow Track Pants'),
(88, 4, 3, 'versace-black-greca-print-lounge-pants', 650, 'versace-black-greca-print-lounge-pants', 'versace-black-greca-print-lounge-pants.jpg', 'versace-black-greca-print-lounge-pants'),
(89, 4, 3, 'versace Printed cotton sweatpants', 999, 'versace Printed cotton sweatpants', 'versace Printed cotton sweatpants.jpg', 'versace Printed cotton sweatpants'),
(90, 4, 3, 'versace PRINTED JERSEY SWEATPANTS', 640, 'versace PRINTED JERSEY SWEATPANTS', 'versace PRINTED JERSEY SWEATPANTS.jpg', 'versace PRINTED JERSEY SWEATPANTS'),
(91, 4, 3, 'versace LOGO EMBROIDERY COTTON SWEATPANTS', 899, 'versace LOGO EMBROIDERY COTTON SWEATPANTS', 'versace LOGO EMBROIDERY COTTON SWEATPANTS.jpg', 'versace LOGO EMBROIDERY COTTON SWEATPANTS'),
(92, 4, 3, 'Versace La Greca Printed Trackpants', 700, 'Versace La Greca Printed Trackpants', 'Versace La Greca Printed Trackpants.jpg', 'Versace La Greca Printed Trackpants'),
(93, 4, 3, 'versace Black Baroque Sides Track Pants', 800, 'versace Black Baroque Sides Track Pants', 'versace Black Baroque Sides Track Pants.jpg', 'versace Black Baroque Sides Track Pants'),
(94, 4, 3, 'Versace Barocco Straight Leg Track Joggers', 880, 'Versace Barocco Straight Leg Track Joggers', 'Versace Barocco Straight Leg Track Joggers.jpg', 'Versace Barocco Straight Leg Track Joggers'),
(255, 4, 1, 'louis-vuitton-graphic-leather-biker-pants', 700, 'louis-vuitton-graphic-leather-biker-pants', 'louis-vuitton-graphic-leather-biker-pants-ready-to-wear--HLL67WZLO002_PM2_Front view.png', 'louis-vuitton-graphic-leather-biker-pants'),
(100, 4,3, 'versace Tartan Baroque Print Trackpants', 920, 'versace Trackpants', '90_E71GAA324-EJS022_EG80_10_TartanBaroquePrintTrackpants-Pants-versace-online-store_0_7.jpg', 'versace Trackpants'),
(101, 4, 5, 'Champion-sports-trousers', 600, 'Champion-sports-trousers', 'brand-men-sports-trousers-new-champion-splicing.jpg', 'Champion-sports-trousers'),
(102, 4, 2, 'Gucci TARTAN CHECK WOOL PANTS', 550, 'gucci TARTAN CHECK WOOL PANTS', '(gucci TARTAN CHECK WOOL PANTS).png', 'gucci TARTAN CHECK WOOL PANTS'),
(103, 4, 2, 'Gucci Track Pants For Men - Farfetch', 700, 'Gucci Track Pants For Men - Farfetch', '(Gucci Track Pants For Men - Farfetch).png', '(Gucci Track Pants For Men - Farfetch)'),
(104, 4, 1, 'Louis Vuitton  Embroidered cigarette pants', 840, 'Louis Vuitton  Embroidered cigarette pants', '(Louis Vuitton  Embroidered cigarette pants).png', 'Louis Vuitton  Embroidered cigarette pants'),
(105, 4, 1, 'Louis Vuitton  Monogram Street Style Logo Pants', 600, 'Louis Vuitton  Monogram Street Style Logo Pants', '(Louis Vuitton  Monogram Street Style Logo Pants).jpg', 'Louis Vuitton  Monogram Street Style Logo Pants'),
(106, 4, 1, 'Louis Vuitton  Monogram Unisex Nylon Blended Fabrics Street Style Logo', 500, 'Louis Vuitton  Monogram Unisex Nylon Blended Fabrics Street Style Logo', '(Louis Vuitton  Monogram Unisex Nylon Blended Fabrics Street Style Logo).jpg', 'Louis Vuitton  Monogram Unisex Nylon Blended Fabrics Street Style Logo'),
(107, 4, 1, 'Louis Vuitton  Pinstripe straight leg trousers', 700, 'Louis Vuitton  Pinstripe straight leg trousers', '(Louis Vuitton  Pinstripe straight leg trousers).png', 'Louis Vuitton  Pinstripe straight leg trousers'),
(108, 4, 1, 'Louis Vuitton  Travertine classic pants', 400, 'Louis Vuitton  Travertine classic pants', '(Louis Vuitton  Travertine classic pants).png', 'Louis Vuitton  Travertine classic pants'),
(109, 4, 1, 'Louis Vuitton  Zigzag Street Style Logo Pants', 660, 'Louis Vuitton  Zigzag Street Style Logo Pants', '(Louis Vuitton  Zigzag Street Style Logo Pants).jpg', 'Louis Vuitton  Zigzag Street Style Logo Pants'),
(110, 4, 1, 'Louis Vuitton DAMIER SWEAT PANTS', 800, 'Louis Vuitton DAMIER SWEAT PANTS', '(Louis Vuitton DAMIER SWEAT PANTS).png', 'Louis Vuitton DAMIER SWEAT PANTS'),
(111, 4, 1, 'Louis Vuitton MONOGRAM CRAZY DENIM PANTS', 700, 'Louis Vuitton MONOGRAM CRAZY DENIM PANTS', '(Louis Vuitton MONOGRAM CRAZY DENIM PANTS).png', 'Louis Vuitton MONOGRAM CRAZY DENIM PANTS'),
(112, 4, 1, 'Louis Vuitton Street Style Logo Joggers & Sweatpants', 600, 'Louis Vuitton Street Style Logo Joggers & Sweatpants', '(Louis Vuitton Street Style Logo Joggers & Sweatpants).jpg', 'Louis Vuitton Street Style Logo Joggers & Sweatpants'),
(113, 4, 1, 'Louis Vuitton Travel Jogging Pants', 870, 'Louis Vuitton Travel Jogging Pants', '(Louis Vuitton Travel Jogging Pants).jpg', 'Louis Vuitton Travel Jogging Pants'),
(114, 4, 2, 'Gucci Sweatpants Nordstrom', 500, 'Sweatpants Gucci  Nordstrom', '(Sweatpants Gucci  Nordstrom).jpg', 'Sweatpants Gucci  Nordstrom'),
(115, 4, 6, 'UIXX-Velcro-Hem-Grayish-Green-Camo-Cargo-Pants', 300, 'Green-Camo-Cargo-Pants', '13.-UIXX-Velcro-Hem-Grayish-Green-Camo-Cargo-Pants.jpg', '13.-UIXX-Velcro-Hem-Grayish-Green-Camo-Cargo-Pants'),
(116, 4, 6, 'Lacoste--blue Street Style trousers', 400, 'blue pants', '14859990_blue_1.jpg', 'blue pants'),
(117, 4, 2, 'Gucci Red Cotton Logo Joggers', 500, 'Red Cotton Logo Joggers', 'Boys Red Cotton Logo Joggers.jpg', 'Boys Red Cotton Logo Joggers'),
(118, 4, 5, 'champion REVERSE WEAVE FRENCH TERRY GARMENT DYE SLIM JOGGERS', 600, 'champion REVERSE WEAVE FRENCH TERRY GARMENT DYE SLIM JOGGERS', 'champion REVERSE WEAVE FRENCH TERRY GARMENT DYE SLIM JOGGERS.jpg', 'champion REVERSE WEAVE FRENCH TERRY GARMENT DYE SLIM JOGGERS'),
(119, 4, 5, 'champion REVERSE WEAVE TRACKPANT', 500, 'champion REVERSE WEAVE TRACKPANT', 'champion REVERSE WEAVE TRACKPANT.jpg', 'champion REVERSE WEAVE TRACKPANT'),
(120, 4, 5, 'champion SCRIPT CUFF TRACK PANT', 600, 'champion SCRIPT CUFF TRACK PANT', 'champion SCRIPT CUFF TRACK PANT.jpg', 'champion SCRIPT CUFF TRACK PANT'),
(121, 4, 4, 'ck Men Black Printed Slim Fit Joggers', 400, 'ck Men Black Printed Slim Fit Joggers', 'ck Men Black Printed Slim Fit Joggers.jpg', 'ck Men Black Printed Slim Fit Joggers'),
(122, 4, 4, 'ck Men Black Printed Track Pants', 600, 'ck Men Black Printed Track Pants', 'ck Men Black Printed Track Pants.jpg', 'ck Men Black Printed Track Pants'),
(123, 4, 4, 'ck Men Grey Melange Slim Fit Solid Pleated Track Pants', 580, 'ck Men Grey Melange Slim Fit Solid Pleated Track Pants', 'ck Men Grey Melange Slim Fit Solid Pleated Track Pants.jpg', 'ck Men Grey Melange Slim Fit Solid Pleated Track Pants'),
(124, 4, 4, 'ck Men Grey Melange Solid Track Pants', 350, 'ck Men Grey Melange Solid Track Pants', 'ck Men Grey Melange Solid Track Pants.jpg', 'ck Men Grey Melange Solid Track Pants'),
(125, 4, 6, 'Nike-track pants', 300, 'nike trousers', 'f249ccb8-17ab-4834-a5bc-c8d269d649c2-800x800.jpeg_495.jpg', 'nike trousers'),
(126, 4, 6, 'Gersri-Straight-Hole-Destruction-Trousers-Distressed-Denim-Trousers-Fashion-Designer-Brand-White.', 900, 'Gersri-Straight-Hole-Destruction-Trousers', 'Gersri-Straight-Hole-Destruction-Trousers-Distressed-Jeans-Men-Denim-Trousers-Men-Jeans-Fashion-Designer-Brand-White.jpg_Q90.jpg_.png', 'Gersri-Straight-Hole-Destruction-Trousers-Distressed-Jeans-Men-Denim-Trousers-Men-Jeans-Fashion-Designer-Brand-White'),
(127, 4, 2, 'Gucci Technical Jersey Joggers In Red', 400, 'gucci Technical Jersey Joggers In Red', 'gucci Technical Jersey Joggers In Red.jpg', 'gucci Technical Jersey Joggers In Red'),
(128, 4, 5, 'champion -cotton jogger', 400, 'jogger pant', 'jogger pante.jpg', 'jogger pant'),
(129, 4, 6, 'Gucci--jogging pants', 700, 'Jogging Gucci', 'Jogging Gucci.jpg', 'Jogging Gucci'),
(130, 4, 4, 'CK-- White Brand Logo Printed Joggers', 900, 'Men White Brand Logo Printed Joggers', 'Men White Brand Logo Printed Joggers.jpg', 'Men White Brand Logo Printed Joggers'),
(131, 4, 6, 'adidas men-red-fancy-lower', 500, 'men-red-fancy-lower', 'men-red-fancy-lower-500x500.jpg', 'men-red-fancy-lower'),
(132, 4, 6, 'Magneto Joggers', 600, 'trousers', 'product-jpeg-500x500 (3).jpg', 'trousers'),
(133, 4, 6, 'Slim Denim Long Trousers With Flowers Elastic Print Pattern', 800, 'Slim Denim Long Trousers With Flowers Elastic Print Pattern', 'Slim Denim Long Trousers With Flowers Elastic Print Pattern.jpg', 'Slim Denim Long Trousers With Flowers Elastic Print Pattern'),
(134, 4, 6, 'Stranger-Things-Joggers-Black-Gray', 700, 'Stranger-Things-Joggers-2019-Brand-Male-Tracksuit-Trousers-Men-Pants-Casual-Pants-Sweatpants-Jogger-Black-Gray', 'Stranger-Things-Joggers-2019-Brand-Male-Tracksuit-Trousers-Men-Pants-Casual-Pants-Sweatpants-Jogger-Black-Gray.jpg_Q90.jpg_.png', 'Stranger-Things-Joggers-2019-Brand-Male-Tracksuit-Trousers-Men-Pants-Casual-Pants-Sweatpants-Jogger-Black-Gray'),
(255, 4, 6, 'Flash ski bib trousers', 680, 'Flash ski bib trousers', 'Flash ski bib trousers.jpg', 'Flash ski bib trousers'),

(135, 5, 1, 'LV STRAIGHT JEANS', 1000, 'STRAIGHT JEANS', 'STRAIGHT JEANS - ANTHRACITE.jpg', 'STRAIGHT JEANS'),
(136, 5, 3, 'Versace tie-dye straight-leg jeans', 1500, 'tie-dye straight-leg jeans', 'tie-dye straight-leg jeans.jpg', 'tie-dye straight-leg jeans'),
(137, 5, 1, 'LV jeans', 1800, 'LV jeans', 'unnamed.jpg', 'LV jeans'),
(138, 5, 3, 'Versace - Greca-print straight-leg jeans', 1999, 'Versace - Greca-print straight-leg jeans', 'Versace - Greca-print straight-leg jeans.jpg', 'Versace - Greca-print straight-leg jeans'),
(139, 5, 3, 'versace black solid jeans', 300, 'versace blsck solid jeans', 'versace blsck solid jeans.jpg', 'versace blsck solid jeans'),
(140, 5, 3, 'versace slim fit jeans', 1100, 'versace', 'versace.jpg', 'versace'),
(141, 5, 4, 'CK Washed Slim Fit Jeans with Contrast Taping', 1300, 'Washed Slim Fit Jeans with Contrast Taping', 'Washed Slim Fit Jeans with Contrast Taping.jpg', 'Washed Slim Fit Jeans with Contrast Taping'),
(142, 5, 2, 'Denim skinny jeans', 1800, 'Denim skinny pant', 'Denim skinny pant.jpg', 'Denim skinny pant'),
(143, 5, 1, 'LV straight-fit-jeans', 1599, 'LV jeans', 'ff64408c498387dfe60d4711a08bda38.jpg_360x360q90.jpg_.jpg', 'LV jeans'),
(144, 5, 6, 'Grunt-dark-blue-mid-waist-rugged-slim-fit-jeans', 2000, 'grunt-dark-blue-mid-waist-rugged-slim-fit-jeans', 'grunt-dark-blue-mid-waist-rugged-slim-fit-jeans.jpg', 'grunt-dark-blue-mid-waist-rugged-slim-fit-jeans'),
(145, 5, 1, 'Louis Vuitton LV mens luxury demin embroidery jeans', 2500, 'Louis Vuitton LV luxury demin embroidery jeans', 'Louis Vuitton LV mens luxury demin embroidery jeans pants G75.jpg', 'Louis Vuitton LV luxury demin embroidery jeans'),
(146, 5, 1, 'Louis Vuitton Men Jeans', 1000, 'Louis Vuitton Men Jeans', 'Louis Vuitton Men Jeans,Louis Vuitton Jeans Fake,Louis Vuitton Pants Mens,Replica Louis Vuitton For Cheap.jpg', 'Louis Vuitton Men Jeans,Louis Vuitton Jeans Fake'),
(147, 5, 1, 'louis-vuitton-monogram-denim-jeans', 2100, 'louis-vuitton-monogram-denim-pants', 'louis-vuitton-monogram-denim-pants-ready-to-wear--HLD55WE53900_PM2_Front view.jpg', 'louis-vuitton-monogram-denim-pants'),
(148, 5, 1, 'louis-vuitton-monogram-workwear-denim-jeans', 2000, 'louis-vuitton-monogram-workwear-denim-pants', 'louis-vuitton-monogram-workwear-denim-pants-ready-to-wear--HLD60WG98175_PM2_Front view.jpg', 'louis-vuitton-monogram-workwear-denim-pants'),
(149, 5, 1, 'louis-vuitton-salt-print-denim-jeans', 1999, 'louis-vuitton-salt-print-denim-pants', 'louis-vuitton-salt-print-denim-pants-ready-to-wear--HLD03WDR0650_PM2_Front view.jpg', 'louis-vuitton-salt-print-denim-pants'),
(150, 5, 1, 'louis-vuitton-wide-leg-denim-jeans', 1500, 'louis-vuitton-wide-leg-denim-pants', 'louis-vuitton-wide-leg-denim-pants-ready-to-wear--HLD70WG58650_PM2_Front view.jpg', 'louis-vuitton-wide-leg-denim-pants'),
(151, 5, 1, 'Monogrammed LV Denim Jeans - Blue', 2300, 'Mens Monogrammed LV Denim Jeans', 'Mens Monogrammed LV Denim Jeans - Blue.jpg', 'Mens Monogrammed LV Denim Jeans'),
(152, 5, 6, 'men-Fashion-hole-straight-Slim-jeans-personality-moustache-effect-Designer-Destroyed-Ripped', 2800, 'Original-brand-jeans-men-Fashion-hole-straight-Slim-jeans-personality-moustache-effect-Men-Designer-Destroyed-Ripped', 'Original-brand-jeans-men-Fashion-hole-straight-Slim-jeans-personality-moustache-effect-Men-Designer-Destroyed-Ripped.png', 'Original-brand-jeans-men-Fashion-hole-straight-Slim-jeans-personality-moustache-effect-Men-Designer-Destroyed-Ripped'),
(153, 5, 6, 'SLIM JEAN - BLACK', 1000, 'SLIM JEAN - BLACK', 'SLIM JEAN - BLACK.jpg', 'SLIM JEAN - BLACK'),
(154, 5, 1, 'LV jeans-light blue', 1400, 'lv jeans', '1e24b507152650d77cd096d77663ce0a.jpg', 'lv jeans'),
(155, 5, 1, 'LV jeans-white', 1000, 'lv jeans', '18490981-1_1.jpg', 'lv jeans'),
(156, 5, 1, 'LV Black-Graphic-Printed-logo', 900, 'lv jeans', '18557378-1_1.jpg', 'lv Black-Graphic-Printed'),
(157, 5, 3, 'Versace BLUE RELAX FIT DENIM JEANS', 1500, 'BLUE RELAX FIT DENIM JEANS', 'BLUE RELAX FIT DENIM JEANS.jpg', 'BLUE RELAX FIT DENIM JEANS'),
(158, 5, 4, 'Calvin Klein Mens Stretch Twill Slim Fit Jeans', 1300, 'Calvin Klein Mens Stretch Twill Slim Fit Jeans', 'Calvin Klein Mens Stretch Twill Slim Fit Jeans.jpg', 'Calvin Klein Mens Stretch Twill Slim Fit Jeans'),
(159, 5, 4, 'ck Men Black Slim Fit Rinsed Cotton Stretch Jeans', 1600, 'ck Men Black Slim Fit Rinsed Cotton Stretch Jeans', 'ck Men Black Slim Fit Rinsed Cotton Stretch Jeans.jpg', 'ck Men Black Slim Fit Rinsed Cotton Stretch Jeans'),
(160, 5, 4, 'ck slim fit', 1200, 'ck slim fit', 'ck slim fit.jpg', 'ck slim fit'),
(161, 5, 1, 'Louis Vuitton Fitted Denim Jeans - Blue', 2000, 'Louis Vuitton Fitted Denim Jeans - Blue', 'Louis Vuitton Graphics Logo Mens Fitted Denim Jeans - Blue.jpg', 'Louis Vuitton Graphics Logo Mens Fitted Denim Jeans - Blue'),
(160, 5, 2, 'GUCCI 5 POCKET CORD JEANs', 1100, 'GUCCI 5 POCKET CORD JEAN', 'GUCCI 5 POCKET CORD JEAN.jpg', 'GUCCI 5 POCKET CORD JEANS'),


(162, 6, 3, 'versace logo-printed Hoodies', 1800, 'versace Hoodies', '4_8df685da-d882-410c-a007-f04d2978d783_1024x1024@2x.jpg', 'versace Hoodies'),
(163, 6, 6, 'Playboy-white -printed Hoodie', 1500, 'playboy', '4_df9dc76e-2b5e-4d3e-8b0f-8e75f60627ab_1024x1024@2x.jpg', 'playboy Hoodies'),
(164, 6, 2, 'Gucci blue logo printed Hoodie', 1300, 'gucci Hoodie', '5_021fa467-5a01-4ec6-8023-ea476d5483db_1024x1024@2x.jpg', 'gucci Hoodie'),
(165, 6, 6, 'Batman logo printed cotton Hoodie', 1999, 'Hoodie', '5a5a54d6f34a9256d6e07139-large.jpg', 'Hoodie'),
(166, 6, 5, 'Champion logo-printed Multicolor Hoodie', 1500, 'Hoodie', '7f607caba9df49bc66899807fb40f1d9.jpg', 'Hoodie'),
(167, 6, 4, 'CK white logo-printed Hoodies', 1300, 'Hoodie', '21c567c35077d7368e4edc23b1866ebb.jpg', 'Hoodie'),
(168, 6, 3, 'Medusa Amplified Print Hoodie-Sweatshirts-versace', 1800, 'MedusaAmplifiedPrintHoodie-Sweatshirts', '90_A88742-1F00721_5B000_10_MedusaAmplifiedPrintHoodie-Sweatshirts-versace-online-store_1_1.jpg', 'MedusaAmplifiedPrintHoodie-Sweatshirts-versace'),
(169, 6, 5, 'Champion oversized print logo', 1700, 'Hoodie', '91pyRDMGhnL._AC_UL1500_.jpg', 'Hoodie'),
(170, 6, 4, 'CK red Hoodie', 1600, 'Hoodie', '7970bf9202d62c6e0b258d6da1721aa8.jpg', 'Hoodie'),
(171, 6, 2, 'Gucci red Printed Hoodie', 1700, 'Hoodie', '14687632_23206202_300.jpg', 'Hoodie'),
(172, 6, 5, 'Champion-Vintage-Script-Black-Hoodie', 1700, 'Hoodie', 'Champion-Boys-Vintage-Script-Black-Hoodie-_330979.jpg', 'Hoodie'),
(173, 6, 3, 'versace -script-white Hoodie', 1800, 'Hoodie', 'd321c9adbe23a3f4e7eb772348caf1f6.jpg', 'Hoodie'),
(174, 6, 1, 'louis-vuitton-3d-patched-pocket-half-zipped-hoodie', 2000, 'lv Hoodie', 'louis-vuitton-3d-patched-pocket-half-zipped-hoodie-ready-to-wear--HHY10WKVR002_PM2_Front view.png', 'louis-vuitton-3d-patched-pocket-half-zipped-hoodie'),
(175, 6, 1, 'louis-vuitton-double-face-hoody', 1900, 'louis-vuitton-double-face-hoody', 'louis-vuitton-double-face-hoody-ready-to-wear--HHB68WOWC139_PM2_Front view.jpg', 'louis-vuitton-double-face-hoody'),
(176, 6, 1, 'louis-vuitton-hoodie-with-bead-shark', 2100, 'louis-vuitton-hoodie-with-bead-shark', 'louis-vuitton-hoodie-with-bead-shark-ready-to-wear--HLY18WIHN631_PM2_Front view.jpg', 'louis-vuitton-hoodie-with-bead-shark'),
(177, 6, 1, 'louis-vuitton-lv-planes-printed-hoodie', 1200, 'Hoodie', 'louis-vuitton-lv-planes-printed-hoodie-ready-to-wear--HIY43WRLE900_PM2_Front view.jpg', 'louis-vuitton-lv-planes-printed-hoodie'),
(178, 6, 1, 'louis-vuitton-mix-nylon-needle-punch-zipped-hoodie', 1600, 'Hoodie', 'louis-vuitton-mix-nylon-needle-punch-zipped-hoodie-ready-to-wear--HIN42WGVD900_PM2_Front view.jpg', 'louis-vuitton-mix-nylon-needle-punch-zipped-hoodie'),
(179, 6, 1, 'louis-vuitton-monogram-mineral-mink-fur-zipped-hoodie', 1999, 'Hoodie', 'louis-vuitton-monogram-mineral-mink-fur-zipped-hoodie-ready-to-wear--HKL40EYQQ629_PM2_Front view.jpg', 'Hoodie'),
(180, 6, 1, 'louis-vuitton-monogram-mink-fur-zipped-hoodie', 2200, 'Hoodie', 'louis-vuitton-monogram-mink-fur-zipped-hoodie-ready-to-wear--HLL19ETKXMU1_PM2_Front view.jpg', 'Hoodie'),
(181, 6, 1, 'louis-vuitton-zip-through-denim-hoodie', 1900, 'Hoodie', 'louis-vuitton-zip-through-denim-hoodie-with-sash-and-patches-ready-to-wear--HHA61WRDH901_PM2_Front view.jpg', 'Hoodie'),
(182, 6, 6, 'Adidas Hoodie', 1300, 'Hoodie', 'man-s-hoody-t-shirt-500x500.jpeg', 'Hoodie'),
(183, 6, 6, 'white Denim Hoodie', 1800, 'Hoodie', 'product-image-1564033089-600x600-1.jpg', 'Hoodie'),
(184, 6, 6, 'white patched pocket script hoodie ', 1200, 'Hoodie', 'product-image-1694074954-600x600-1.jpg', 'Hoodie'),
(185, 6, 6, 'puma-printed-blue-hoodie', 1100, 'hoodie', 'product-jpeg-500x500 (4).jpg', 'Hoodie'),
(79, 6, 6, 'Inferno Assassins Creed Swag-Hoodie', 2569, 'Inferno Assassins Creed Swag-Hoodie', 'product09.png', 'Inferno Assassins Creed Swag-Hoodie'),

(186, 7, 1, 'louis-vuitton-napolitana-jacket', 4300, 'louis-vuitton-napolitana-jacket', 'louis-vuitton-napolitana-jacket-ready-to-wear--HKFJ2WZCUC65_PM2_Front view.jpg', 'louis-vuitton-napolitana-jacket'),
(187, 7, 1, 'louis-vuitton-pinstripe-jacket', 3300, 'louis-vuitton-pinstripe-jacket', 'louis-vuitton-pinstripe-jacket-ready-to-wear--HLJ60EGA3631_PM2_Front view.png', 'louis-vuitton-pinstripe-jacket'),
(188, 7, 1, 'louis-vuitton-pont-neuf-evening-jacket', 2500, 'louis-vuitton-pont-neuf-evening-jacket', 'louis-vuitton-pont-neuf-evening-jacket-ready-to-wear--HKFJ3WZQO901_PM2_Front view.png', 'louis-vuitton-pont-neuf-evening-jacket'),
(189, 7, 1, 'louis-vuitton-raw-edge-multicheck-leather-jacket', 2200, 'louis-vuitton-raw-edge-multicheck-leather-jacket', 'louis-vuitton-raw-edge-multicheck-leather-jacket-ready-to-wear--HLL72ETGXMU1_PM2_Front view.jpg', 'louis-vuitton-raw-edge-multicheck-leather-jacket'),
(190, 7, 1, 'louis-vuitton-reversible-down-gilet', 1300, 'louis-vuitton-reversible-down-gilet', 'louis-vuitton-reversible-down-gilet-ready-to-wear--HDG42WPPX620_PM2_Front view.jpg', 'louis-vuitton-reversible-down-gilet'),
(191, 7, 1, 'louis-vuitton-silver-finish-mink-fur', 2500, 'louis-vuitton-silver-finish-mink-fur', 'louis-vuitton-silver-finish-mink-fur-ready-to-wear--HLL94EGX5996_PM2_Front view.jpg', 'louis-vuitton-silver-finish-mink-fur'),
(192, 7, 1, 'louis-vuitton-travertine-90-s-jacket', 2100, 'louis-vuitton-travertine-90-s-jacket', 'louis-vuitton-travertine-90-s-jacket-ready-to-wear--HLJ62WFS0013_PM2_Front view.jpg', 'louis-vuitton-travertine-90-s-jacket'),
(193, 7, 1, 'louis-vuitton-window-pane-jacket', 2600, 'louis-vuitton-window-pane-jacket', 'louis-vuitton-window-pane-jacket-ready-to-wear--HLJ72EFV5900_PM2_Front view.jpg', 'louis-vuitton-window-pane-jacket'),
(194, 7, 2, 'satin lapel tuxedo jacket', 1300, 'satin lapel tuxedo jacket', 'satin lapel tuxedo jacket.jpg', 'satin lapel tuxedo jacket'),
(195, 7, 1, 'louis-vuitton-damier-suit-jacket', 1800, 'louis-vuitton-damier-suit-jacket', 'louis-vuitton-damier-suit-jacket-ready-to-wear--HMJ01WHE8618_PM2_Front view.jpg', 'louis-vuitton-damier-suit-jacket'),
(196, 7, 1, 'louis-vuitton-double-face-monogram-cutaway-jacket', 2000, 'louis-vuitton-double-face-monogram-cutaway-jacket', 'louis-vuitton-double-face-monogram-cutaway-jacket-ready-to-wear--HMFJ6WZIX631_PM2_Front view.jpg', 'louis-vuitton-double-face-monogram-cutaway-jacket'),
(197, 7, 1, 'louis-vuitton-extra-large-jacket', 1900, 'louis-vuitton-extra-large-jacket', 'louis-vuitton-extra-large-jacket-ready-to-wear--HLJ72WTCX900_PM2_Front view.jpg', 'louis-vuitton-extra-large-jacket'),
(198, 7, 1, 'louis-vuitton-fox-fur-jacket', 1899, 'louis-vuitton-fox-fur-jacket', 'louis-vuitton-fox-fur-jacket-ready-to-wear--HHL16WOUT702_PM2_Front view.jpg', 'louis-vuitton-fox-fur-jacket'),
(199, 7, 1, 'louis-vuitton-lv-hooded-leather-jacket', 1700, 'louis-vuitton-lv-hooded-leather-jacket', 'louis-vuitton-lv-hooded-leather-jacket-ready-to-wear--HLL03EGCQ900_PM2_Front view.jpg', 'louis-vuitton-lv-hooded-leather-jacket'),
(200, 7, 1, 'louis-vuitton-monogram-intarsia-mink-fur-gilet', 1300, 'louis-vuitton-monogram-intarsia-mink-fur-gilet', 'louis-vuitton-monogram-intarsia-mink-fur-gilet-ready-to-wear--HHL08WOUS702_PM2_Front view.png', 'louis-vuitton-monogram-intarsia-mink-fur-gilet'),
(201, 7, 1, 'louis-vuitton-monogram-mirror-shearling-jacket', 2100, 'louis-vuitton-monogram-mirror-shearling-jacket', 'louis-vuitton-monogram-mirror-shearling-jacket-ready-to-wear--HLL81WFI7996_PM2_Front view.jpg', 'louis-vuitton-monogram-mirror-shearling-jacket'),
(202, 7, 1, 'louis-vuitton-monogram-pocket-shearling-blouson', 2000, 'louis-vuitton-monogram-pocket-shearling-blouson', 'louis-vuitton-monogram-pocket-shearling-blouson-ready-to-wear--HLL68EFW4002_PM2_Front view.jpg', 'louis-vuitton-monogram-pocket-shearling-blouson'),
(203, 7, 1, 'louis-vuitton-monogram-workwear-denim-jacket', 1300, 'louis-vuitton-monogram-workwear-denim-jacket', 'louis-vuitton-monogram-workwear-denim-jacket-ready-to-wear--HLA60WG98315_PM2_Front view.jpg', 'louis-vuitton-monogram-workwear-denim-jacket'),
(204, 7, 1, 'louis-vuitton-belted-damier-jacket', 2600, 'louis-vuitton-belted-damier-jacket', 'louis-vuitton-belted-damier-jacket-ready-to-wear--HLJ35WGZ8105_PM2_Front view.jpg', 'louis-vuitton-belted-damier-jacket'),
(205, 7, 1, 'louis-vuitton-boxy-damier-jacket', 2300, 'louis-vuitton-boxy-damier-jacket', 'louis-vuitton-boxy-damier-jacket-ready-to-wear--HLJ34WIM5900_PM2_Front view.jpg', 'louis-vuitton-boxy-damier-jacket'),
(206, 7, 2, 'gucci check-wool jacket.', 2200, 'gucci check-wool jacket', 'gucci check-wool jacket.jpg', 'gucci check-wool jacket'),
(207, 7, 2, 'gucci dragon Appliquéd Bomber Jacket', 1900, 'gucci dragon Appliquéd Bomber Jacket', 'gucci dragon Appliquéd Bomber Jacket.jpg', 'gucci dragon Appliquéd Bomber Jacket'),
(208, 7, 2, 'gucci GG striped wool blazer', 1899, 'gucci GG striped wool blazer', 'gucci GG striped wool blazer.jpg', 'gucci GG striped wool blazer'),
(209, 7, 2, 'GUCCI LEOPARD PRINT HARRINGTON JACKET', 2100, 'GUCCI LEOPARD PRINT HARRINGTON JACKET', 'GUCCI LEOPARD PRINT HARRINGTON JACKET.jpg', 'GUCCI LEOPARD PRINT HARRINGTON JACKET'),
(210, 7, 2, 'gucci velvet single-breasted blazer', 1999, 'gucci velvet single-breasted blazer', 'gucci velvet single-breasted blazer.jpg', 'gucci velvet single-breasted blazer'),
(211, 7, 2, 'gucci lambskin leather bomber jacket', 1800, 'lambskin leather bomber jacket', 'lambskin leather bomber jacket.jpg', 'lambskin leather bomber jacket'),
(212, 7, 2, 'gucci Leather bomber with Gucci pool patch', 1100, 'Leather bomber with Gucci pool patch', 'Leather bomber with Gucci pool patch.jpg', 'Leather bomber with Gucci pool patch'),
(213, 7, 2, 'gucci GG star cotton jacquard bomber jacket', 2500, 'GG star cotton jacquard bomber jacket', 'GG star cotton jacquard bomber jacket.jpg', 'GG star cotton jacquard bomber jacket'),
(214, 7, 3, 'Logo DenimJackets-versace', 1900, 'LogoDenimJacket-DenimJackets-versace', '90_1000798-1A00596_6D050_10_LogoDenimJacket-DenimJackets-versace-online-store_2_2.jpg', 'Logo DenimJackets-versace'),
(215, 7, 3, 'Leather BikerJacket-Jackets and Coats-versace', 2300, 'NappaLeatherBikerJacket-JacketsandCoats-versace', '90_1001070-1A00713_1B000_10_NappaLeatherBikerJacket-JacketsandCoats-versace-online-store_2_2.jpg', 'NappaLeatherBikerJacket-JacketsandCoats-versace'),
(216, 7, 3, 'Greca Pattern Quilted Jacket-Jackets-versace', 2100, 'GrecaPatternQuiltedJacket-Jackets-versace', '90_A87432-A230630_A1008_10_GrecaPatternQuiltedJacket-Jackets-versace-online-store_6_1.jpg', 'GrecaPatternQuiltedJacket-Jackets-versace'),
(217, 7, 3, 'Greca Puffer Jacket-Jackets-versace', 1600, 'GrecaPufferJacket-Jackets-versace', '90_A88692-A233255_A1008_10_GrecaPufferJacket-Jackets-versace-online-store_2_2.jpg', 'GrecaPufferJacket-Jackets-versace'),
(218, 7, 4, 'Logo Bomber Jacket Ck Black', 1500, 'Logo Bomber Jacket (Ck Black)', 'Logo Bomber Jacket (Ck Black).jpg', 'Logo Bomber Jacket (Ck Black)'),
(219, 7, 4, 'Calvin Klein Side Logo Truck Jacket', 1400, 'Calvin Klein Side Logo Truck Jacket', 'Calvin Klein Side Logo Truck Jacket.jpg', 'Calvin Klein Side Logo Truck Jacket'),
(220, 7, 4, 'Calvin Klein Jeans Short Down Jacket', 2800, 'Calvin Klein Jeans Short Down Jacket', 'Calvin Klein Jeans Short Down Jacket.jpg', 'Calvin Klein Jeans Short Down Jacket'),
(221, 7, 5, 'champion-red-jacket', 1500, 'champion-215246-rs041-jacket', 'champion-215246-rs041-jacket_2.jpg', 'champion-215246-rs041-jacket'),
(222, 7, 5, 'champion-sherpa-fleece-jacket', 1799, 'champion-sherpa-fleece-jacket', 'champion-sherpa-fleece-jacket-worn-by-da-in-his-my-last-words-music-video.jpg', 'champion-sherpa-fleece-jacket'),
(223, 7, 5, 'champion-track jacket', 1400, 'champion-track jacket', 'champion-track jacket.jpg', 'champion-track jacket'),

(224, 8, 6, 'Double Dhoti White with Gold Jari 2 1/2 Kaviyam', 700, 'Double Dhoti White with Gold Jari 2 1-2 Kaviyam', 'Double Dhoti White with Gold Jari 2 1-2 Kaviyam.jpg', 'Double Dhoti White with Gold Jari 2 1/2 Kaviyam'),
(225, 8, 6, 'Mens Colour Dhoti with Fancy Border', 630, 'Mens Colour Dhoti with Fancy Border', 'Mens Colour Dhoti with Fancy Border.jpg', 'Mens Colour Dhoti with Fancy Border'),
(226, 8, 6, 'Mens Colour Dhoti with Gold Jari', 730, 'Mens Colour Dhoti with Gold Jari', 'Mens Colour Dhoti with Gold Jari.jpg', 'Mens Colour Dhoti with Gold Jari'),
(227, 8, 6, 'Mens Combo Set White Dhoti,Shirt Bit&Towel 1/2 Gold Jari Vaisant', 2000, 'Mens Combo Set White Dhoti,Shirt Bit&Towel 1-2 Gold Jari Vaisant', 'Mens Combo Set White Dhoti,Shirt Bit&Towel 1-2 Gold Jari Vaisant.jpg', 'Mens Combo Set White Dhoti,Shirt Bit&Towel 1-2 Gold Jari Vaisant'),
(228, 8, 6, 'Mens Cotton Lungi Rainbow', 500, 'Mens Cotton Lungi Rainbow', 'Mens Cotton Lungi Rainbow.jpg', 'Mens Cotton Lungi Rainbow'),
(229, 8, 6, 'Mens Double Dhoti with Fancy Border Panchami Fancy Blue', 800, 'Mens Double Dhoti with Fancy Border Panchami Fancy Blue', 'Mens Double Dhoti with Fancy Border Panchami Fancy Blue.jpg', 'Mens Double Dhoti with Fancy Border Panchami Fancy Blue'),
(230, 8, 6, 'Mens Panchakacham Dhoti with Angavasthram Navaratnam GY', 1130, 'Mens Panchakacham Dhoti with Angavasthram Navaratnam GY', 'Mens Panchakacham Dhoti with Angavasthram Navaratnam GY.jpg', 'Mens Panchakacham Dhoti with Angavasthram Navaratnam GY'),
(231, 8, 6, 'Mens Ready Made Panchakacham Cream Prakaspati', 1000, 'Mens Ready Made Panchakacham Cream Prakaspati', 'Mens Ready Made Panchakacham Cream Prakaspati .jpg', 'Mens Ready Made Panchakacham Cream Prakaspati'),
(232, 8, 6, 'Mens Single Dhoti White with Silver Jari', 600, 'Mens Single Dhoti White with Silver Jari', 'Mens Single Dhoti White with Silver Jari.jpg', 'Mens Single Dhoti White with Silver Jari'),

(233, 9, 1, 'louis-vuitton-watercolor-swim-shorts', 850, 'louis-vuitton-watercolor-swim-short', 'louis-vuitton-watercolor-swim-short-ready-to-wear--HLW05WDA0MU1_PM2_Front view.jpg', 'louis-vuitton-watercolor-swim-short'),
(234, 9, 1, 'louis-vuitton-3d-pocket-monogram-board-shorts', 660, 'louis-vuitton-3d-pocket-monogram-board-shorts', 'louis-vuitton-3d-pocket-monogram-board-shorts-ready-to-wear--HLW55WOSJ624_PM2_Front view.jpg', 'louis-vuitton-3d-pocket-monogram-board-shorts'),
(235, 9, 1, 'louis-vuitton-louis-vuitton-2054-packable-swimwear', 500, 'louis-vuitton-louis-vuitton-2054-packable-swimwear', 'louis-vuitton-louis-vuitton-2054-packable-swimwear-ready-to-wear--HMW08WKN2624_PM2_Front view.jpg', 'louis-vuitton-louis-vuitton-2054-packable-swimwear'),
(236, 9, 1, 'louis-vuitton-monogram-board-shorts', 550, 'louis-vuitton-monogram-board-shorts', 'louis-vuitton-monogram-board-shorts-ready-to-wear--HDW50WPUA587_PM2_Front view.png', 'louis-vuitton-monogram-board-shorts'),
(237, 9, 1, 'louis-vuitton-water-monogram-board-shorts', 700, 'louis-vuitton-water-monogram-board-shorts', 'louis-vuitton-water-monogram-board-shorts-ready-to-wear--HLW53WDO6900_PM2_Front view.jpg', 'louis-vuitton-water-monogram-board-shorts'),
(238, 9, 2, 'gucci patch detailed mesh bermuda shorts', 450, 'gucci patch detailed mesh bermuda shorts', 'gucci patch detailed mesh bermuda shorts.jpg', 'gucci patch detailed mesh bermuda shorts'),
(239, 9, 2, 'gucci Liberty floral-print shorts', 430, 'gucci Liberty floral-print shorts', 'gucci Liberty floral-print shorts.jpg', 'gucci Liberty floral-print shorts'),
(240, 9, 2, 'gucci GG jacquard shorts', 400, 'GG jacquard shorts', 'GG jacquard shorts.jpg', 'GG jacquard shorts'),
(241, 9, 3, 'Logo-Short-Swim-Shorts-Beachwear-versace', 600, 'LogoShortSwimShorts-Beachwear-versace', '90_1001348-1A01032_5O070_10_LogoShortSwimShorts-Beachwear-versace-online-store_0_0.jpg', 'LogoShortSwimShorts-Beachwear-versace'),
(242, 9, 3, 'Logo-Swim-Shorts-Beachwear-versace-grey', 599, 'LogoSwimShorts-Beachwear-versace', '90_1001349-1A01032_5B040_10_LogoSwimShorts-Beachwear-versace-online-store_0_0.jpg', 'LogoSwimShorts-Beachwear-versace'),
(243, 9, 3, 'LaCoupe DesDieux Swim Short Shorts-Beachwear-versace', 520, 'LaCoupeDesDieuxSwimShortShorts', '90_1002516-1A01858_5B090_10_LaCoupeDesDieuxSwimShortShorts-Beachwear-versace-online-store_0_1.jpg', 'LaCoupeDesDieuxSwimShortShorts-Beachwear-versace'),
(244, 9, 3, 'La Greca Print Swim Shorts-Beachwear-versace', 399, 'LaGrecaPrintSwimShorts-Beachwear-versace', '90_1002517-1A01767_5R080_10_LaGrecaPrintSwimShorts-Beachwear-versace-online-store_0_1.jpg', 'LaGrecaPrintSwimShorts-Beachwear-versace'),
(245, 9, 3, 'Greca Shorts-Pants-versace', 480, 'GrecaShorts-PantsandShorts-versace', '90_1003163-1A02223_1U820_10_GrecaShorts-PantsandShorts-versace-online-store_0_2.jpg', 'GrecaShorts-PantsandShorts-versace'),
(246, 9, 3, 'BaroccoShorts-Activewear-versace', 510, 'BaroccoShorts-Activewear-versace', '90_1003730-1A02576_5B010_10_BaroccoShorts-Activewear-versace-online-store_0_1.jpg', 'BaroccoShorts-Activewear-versace'),
(247, 9, 3, 'LaGrecaGymShorts-Activewear-versace', 470, 'LaGrecaGymShorts-Activewear-versace', '90_1004117-1A03004_6U690_10_LaGrecaGymShorts-Activewear-versace-online-store_0_1.jpg', 'LaGrecaGymShorts-Activewear-versace'),
(248, 9, 3, 'WildBaroque-Print-Short-Swim-Shorts-Beachwear-versace', 630, 'WildBaroquePrintShortSwimShorts-Beachwear', '90_ABU08028-A232997_A7900_10_WildBaroquePrintShortSwimShorts-Beachwear-versace-online-store_7_7.jpg', 'WildBaroquePrintShortSwimShorts-Beachwear-versace'),
(249, 9, 3, 'Logo Long SwimShorts-Beachwear-versace', 400, 'LogoLongSwimShorts-Beachwear-versace', '90_ABU90005-1F01235_1B000_10_LogoLongSwimShorts-Beachwear-versace-online-store_1_2.jpg', 'LogoLongSwimShorts-Beachwear-versace'),
(250, 9, 4, 'ck Men White Mid-Rise Regular Shorts', 440, 'ck Men White Mid-Rise Regular Shorts', 'ck Men White Mid-Rise Regular Shorts.jpg', 'ck Men White Mid-Rise Regular Shorts'),
(251, 9, 4, 'ck Men Yellow Brand logo Printed Applique Pure Cotton Regular Shorts', 500, 'ck Men Yellow Brand logo Printed Applique Pure Cotton Regular Shorts', 'ck Men Yellow Brand logo Printed Applique Pure Cotton Regular Shorts.jpg', 'ck Men Yellow Brand logo Printed Applique Pure Cotton Regular Shorts'),
(252, 9, 4, 'ck Men Black Mid-Rise Regular Shorts', 420, 'Men Black Mid-Rise Regular Shorts', 'Men Black Mid-Rise Regular Shorts.jpg', 'Men Black Mid-Rise Regular Shorts'),
(253, 9, 5, 'Champion Inseam Cotton Jersey Shorts with Pockets', 500, 'Champion 8180 Mens 9 Inseam Cotton Jersey Shorts with Pockets', 'Champion 8180 Mens 9 Inseam Cotton Jersey Shorts with Pockets.jpg', 'Champion 8180 Mens 9 Inseam Cotton Jersey Shorts with Pockets'),
(254, 9, 5, 'Champion Big and Tall Shorts for Men - Athletic Fit Jersey Shorts', 560, 'Champion Big and Tall Shorts for Men - Athletic Fit Jersey Shorts', 'Champion Big and Tall Shorts for Men - Athletic Fit Jersey Shorts.jpg', 'Champion Big and Tall Shorts for Men - Athletic Fit Jersey Shorts'),
(255, 9, 5, 'Champion Mens 7-inch Specialty Dye Fleece Short', 700, 'Champion Mens 7-inch Specialty Dye Fleece Short', 'Champion Mens 7-inch Specialty Dye Fleece Short.jpg', 'Champion Mens 7-inch Specialty Dye Fleece Short'),
(255, 9, 5, 'Champion Mens 7-inch Taped AOP Mesh Short', 490, 'Champion Mens 7-inch Taped AOP Mesh Short', 'Champion Mens 7-inch Taped AOP Mesh Short.jpg', 'Champion Mens 7-inch Taped AOP Mesh Short'),
(255, 9, 5, 'Champion Mens Big and Tall Lightweight Cotton Jersey Shorts with Script Logo', 500, 'Champion Mens Big and Tall Lightweight Cotton Jersey Shorts with Script Logo', 'Champion Mens Big and Tall Lightweight Cotton Jersey Shorts with Script Logo.jpg', 'Champion Mens Big and Tall Lightweight Cotton Jersey Shorts with Script Logo'),
(255, 9, 5, 'Champion Shorts, Big and Tall Shorts for Men, Mesh Mens Shorts', 560, 'Champion Shorts, Big and Tall Shorts for Men, Mesh Mens Shorts', 'Champion Shorts, Big and Tall Shorts for Men, Mesh Mens Shorts.jpg', 'Champion Shorts, Big and Tall Shorts for Men, Mesh Mens Shorts'),
(255, 9, 6, 'asics Fujitrail track shorts', 450, 'asics Fujitrail track shorts', 'asics Fujitrail track shorts.jpg', 'asics Fujitrail track shorts'),
(255, 9, 6, 'pas normal studios-Essential bib shorts', 400, 'pas normal studios-Essential bib shorts', 'pas normal studios-Essential bib shorts.jpg', 'pas normal studios-Essential bib shorts'),


(255, 10, 6, 'VanHeusen-Men Blue & Grey Checked Slim-Fit Single-Breasted 3-Piece Formal Suit', 3000, 'VanHeusen-Men Blue & Grey Checked Slim-Fit Single-Breasted 3-Piece Formal Suit', 'VanHeusen-Men Blue & Grey Checked Slim-Fit Single-Breasted 3-Piece Formal Suit.jpg', 'VanHeusen-Men Blue & Grey Checked Slim-Fit Single-Breasted 3-Piece Formal Suit'),
(255, 10, 2, 'gucci single-breasted suit', 3500, 'single-breasted suit', 'single-breasted suit.jpg', 'single-breasted suit'),
(255, 10, 1, 'louis-vuitton--skim fit suit', 4000, 'louis-vuitton--Men_Show', 'louis-vuitton--Men_Show_SS21_LOOK07_VISUAL4.jpg', 'louis-vuitton--Men_Show'),
(255, 10, 6, 'lp Men Grey Striped Slim Fit Single Breasted Formal Suit', 3900, 'lp Men Grey Striped Slim Fit Single Breasted Formal Suit', 'lp Men Grey Striped Slim Fit Single Breasted Formal Suit.jpg', 'lp Men Grey Striped Slim Fit Single Breasted Formal Suit'),
(255, 10, 6, 'lv Co-ord Suits', 4100, 'lv Co-ord Suits', 'lv Co-ord Suits.jpg', 'lv Co-ord Suits'),
(255, 10, 1, 'lv WOOL SUIT', 3090, 'lv WOOL SUIT', 'lv WOOL SUIT  .jpg', 'lv WOOL SUIT '),
(255, 10, 1, 'lv WOOL SUIT - BLACK', 3299, 'lv WOOL SUIT - BLACK ', 'lv WOOL SUIT - BLACK .jpg', 'lv WOOL SUIT - BLACK'),
(255, 10, 1, 'peter england Men Navy Three Piece Suit', 4400, 'peter england Men Navy Three Piece Suit', 'peter england Men Navy Three Piece Suit.jpg', 'peter england Men Navy Three Piece Suit'),
(255, 10, 6, 'ABLAZE-BLAZER-BLUE', 2999, 'rarerabbit ABLAZE-BLAZER-BLUE', 'rarerabbit ABLAZE-BLAZER-BLUE.jpg', 'ABLAZE-BLAZER-BLUE'),
(255, 10, 6, 'blackberry Men Grey & Navy Blue Checked Slim Fit Single-Breasted Partywear 3-Piece Suit', 3700, 'blackberry Men Grey & Navy Blue Checked Slim Fit Single-Breasted Partywear 3-Piece Suit', 'blackberry Men Grey & Navy Blue Checked Slim Fit Single-Breasted Partywear 3-Piece Suit.jpg', 'blackberry Men Grey & Navy Blue Checked Slim Fit Single-Breasted Partywear 3-Piece Suit'),
(255, 10, 4, 'ck Mens Blazer Black Size 44 Long Two-Button Slim Fit Wool', 2300, 'ck Mens Blazer Black Size 44 Long Two-Button Slim Fit Wool', 'ck Mens Blazer Black Size 44 Long Two-Button Slim Fit Wool.jpg', 'ck Mens Blazer Black Size 44 Long Two-Button Slim Fit Wool'),
(255, 10, 4, 'ck Mens White Size 48 Long 2-Piece Linen Slim Fit Pant Suit', 2900, 'ck Mens White Size 48 Long 2-Piece Linen Slim Fit Pant Suit', 'ck Mens White Size 48 Long 2-Piece Linen Slim Fit Pant Suit.jpg', 'ck Mens White Size 48 Long 2-Piece Linen Slim Fit Pant Suit'),
(255, 10, 2, 'gucci embroidered GG suit', 3800, 'gucci embroidered GG suit', 'gucci embroidered GG suit.jpg', 'gucci embroidered GG suit'),
(255, 10, 2, 'gucci Heritage Interlocking G stripe suit', 2999, 'gucci Heritage Interlocking G stripe suit', 'gucci Heritage Interlocking G stripe suit.jpg', 'gucci Heritage Interlocking G stripe suit'),
(255, 10, 2, 'gucci slim-fit two-piece suit', 2600, 'gucci slim-fit two-piece suit', 'gucci slim-fit two-piece suit.jpg', 'gucci slim-fit two-piece suit'),
(255, 10, 2, 'gucci velvet single-breasted blazer', 3300, 'gucci velvet single-breasted', 'gucci velvet single-breasted blazer-b.jpg', 'gucci velvet single-breasted blazer'),
(255, 10, 1, 'lv WOOL SUIT - ANTHRACITE', 1600, 'lv WOOL SUIT - ANTHRACITE', 'lv WOOL SUIT - ANTHRACITE .jpg', 'lv WOOL SUIT - ANTHRACITE'),
(255, 10, 1, 'lv WOOL SUIT - NAVY', 1900, 'lv WOOL SUIT - NAVY', 'lv WOOL SUIT - NAVY.jpg', 'lv WOOL SUIT - NAVY'),
(255, 10, 3, 'PinstripeArgyleWool Jacquard Blazer-Blazers and Suits-versace', 1300, 'PinstripeArgyleWoolJacquardBlazer-BlazersandSuits-versace', '90_1000984-1A00895_2U220_10_PinstripeArgyleWoolJacquardBlazer-BlazersandSuits-versace-online-store_0_3.jpg', 'PinstripeArgyleWoolJacquardBlazer-BlazersandSuits-versace'),
(255, 10, 3, 'LaGrecaGabardineBlazer-Blazers and Suits-versace', 2100, 'LaGrecaGabardineBlazer-BlazersandSuits-versace', '90_1001834-1A01820_5U180_10_LaGrecaGabardineBlazer-BlazersandSuits-versace-online-store_1_2.jpg', 'LaGrecaGabardineBlazer-BlazersandSuits-versace'),
(255, 10, 6, 'Blended Fabrics Suits', 2200, 'Blended Fabrics Suits', 'Blended Fabrics Suits.jpg', 'Blended Fabrics Suits'),
(255, 10, 6, 'waistcoat-suit', 1000, 'waistcoat', '4fc65b2ab514a080e201ca8fc7433e2d.jpg', 'waistcoat'),
(255, 10, 6, 'Men Black & Gold-Coloured Printed Single-Breasted 2-Piece Slim-Fit Bandhgala Suit', 6000, 'Men Black & Gold-Coloured Printed Single-Breasted 2-Piece Slim-Fit Bandhgala Suit', 'Men Black & Gold-Coloured Printed Single-Breasted 2-Piece Slim-Fit Bandhgala Suit.jpg', 'Men Black & Gold-Coloured Printed Single-Breasted'),
(255, 10, 6, 'Men Burgundy Solid Vest & Pant Set', 3000, 'Men Burgundy Solid Vest & Pant Set', 'Men Burgundy Solid Vest & Pant Set.jpg', 'Men Burgundy Solid Vest & Pant Set'),

(255, 11, 3, 'IBaroqueBathrobe-Bathrobes-versace', 3100, 'IBaroqueBathrobe-Bathrobes-versace', '90_ZACJ00008-ZCOSP052_Z4003_20_IBaroqueBathrobe-Bathrobes-versace-online-store_10_3.jpg', 'IBaroqueBathrobe-Bathrobes-versace'),
(255, 11, 3, 'IBaroque-Bathrobes-versace', 3099, 'IBaroqueBathrobe-Bathrobes-versace', '90_ZACJ00008-ZCOSP052_Z4004_20_IBaroqueBathrobe-Bathrobes-versace-online-store_6_1.jpg', 'IBaroqueBathrobe-Bathrobes-versace'),
(255, 11, 3, 'Virtus Dressing Gown-Bathrobes-versace', 2999, 'VirtusDressingGown-Bathrobes-versace', '90_ZACJ00017-ZCOSP128_Z7554_20_VirtusDressingGown-Bathrobes-versace-online-store_1_1.jpg', 'VirtusDressingGown-Bathrobes-versace'),
(255, 11, 3, 'IBaroque Hooded Dressing Gown-Bathrobes-versace', 2800, 'IBaroqueHoodedDressingGown-Bathrobes-versace', '90_ZACJ00019-ZCOSP052_Z4584_20_IBaroqueHoodedDressingGown-Bathrobes-versace-online-store_4_1.jpg', 'IBaroqueHoodedDressingGown-Bathrobes-versace'),
(255, 11, 3, 'LaCoupe-DesDieux Print Bathrobe-Bathrobes-versace', 3800, 'LaCoupeDesDieuxPrintBathrobe-Bathrobes-versace', '90_ZACP00001-ZCOSP094_Z7624_20_LaCoupeDesDieuxPrintBathrobe-Bathrobes-versace-online-store_4_1.jpg', 'LaCoupeDesDieuxPrintBathrobe-Bathrobes-versace'),
(255, 11, 3, 'IBaroquePrintBathrobe-Bathrobes-versace', 3100, 'IBaroquePrintBathrobe-Bathrobes-versace', '90_ZACP00008-ZCOSP075_Z7621_20_IBaroquePrintBathrobe-Bathrobes-versace-online-store_6_1.jpg', 'IBaroquePrintBathrobe-Bathrobes-versace'),
(255, 11, 3, 'gucci shearling trim knee-length coat', 2100, 'gucci shearling trim knee-length coat', 'gucci shearling trim knee-length coat.jpg', 'gucci shearling trim knee-length coat'),
(255, 11, 3, 'gucci SINGLE BREAST WOOL BLEND COAT', 2500, 'gucci SINGLE BREAST WOOL BLEND COAT', 'gucci SINGLE BREAST WOOL BLEND COAT.jpg', 'gucci SINGLE BREAST WOOL BLEND COAT'),
(255, 11, 3, 'gucci Wool Check Coat', 2700, 'gucci Wool Check Coat', 'gucci Wool Check Coat.jpg', 'gucci Wool Check Coat'),
(255, 11, 3, 'gucci-blue-Logo-jacquard-Wool-blend-Coat', 2300, 'gucci-blue-Logo-jacquard-Wool-blend-Coat', 'gucci-blue-Logo-jacquard-Wool-blend-Coat.jpeg', 'gucci-blue-Logo-jacquard-Wool-blend-Coat'),
(255, 11, 1, 'louis-vuitton-double-breasted-tailored-coat', 2200, 'louis-vuitton-double-breasted-tailored-coat', 'louis-vuitton-double-breasted-tailored-coat-ready-to-wear--HHC40WJPX102_PM2_Front view.jpg', 'louis-vuitton-double-breasted-tailored-coat'),
(255, 11, 1, 'louis-vuitton-extra-long-coat', 3700, 'louis-vuitton-extra-long-coat', 'louis-vuitton-extra-long-coat-ready-to-wear--HLC66WYZS900_PM2_Front view.jpg', 'louis-vuitton-extra-long-coat'),
(255, 11, 1, 'louis-vuitton-lvxnba-classic-coat', 3400, 'louis-vuitton-lvxnba-classic-coat', 'louis-vuitton-lvxnba-classic-coat-ready-to-wear--HLC05WDH8900_PM2_Front view.jpg', 'louis-vuitton-lvxnba-classic-coat'),
(255, 11, 1, 'louis-vuitton-monogram-mirror-raincoat', 3200, 'louis-vuitton-monogram-mirror-raincoat', 'louis-vuitton-monogram-mirror-raincoat-ready-to-wear--HLC91WHF2720_PM2_Front view.jpg', 'louis-vuitton-monogram-mirror-raincoat'),
(255, 11, 1, 'louis-vuitton-monogram-shearling-coat', 3060, 'louis-vuitton-monogram-shearling-coat', 'louis-vuitton-monogram-shearling-coat-ready-to-wear--HHL70ERDA740_PM2_Front view.jpg', 'louis-vuitton-monogram-shearling-coat'),
(255, 11, 1, 'louis-vuitton-sb-multi-pockets-coat', 3100, 'louis-vuitton-sb-multi-pockets-coat', 'louis-vuitton-sb-multi-pockets-coat-ready-to-wear--HHC02WNQY711_PM2_Front view.jpg', 'louis-vuitton-sb-multi-pockets-coat'),
(255, 11, 1, 'louis-vuitton-silver-monogram-felt-coat', 3090, 'louis-vuitton-silver-monogram-felt-coat', 'louis-vuitton-silver-monogram-felt-coat-ready-to-wear--HLC70WHI8720_PM2_Front view.jpg', 'louis-vuitton-silver-monogram-felt-coat'),
(255, 11, 1, 'louis-vuitton-tartan-check-extra-large-coat', 2899, 'louis-vuitton-tartan-check-extra-large-coat', 'louis-vuitton-tartan-check-extra-large-coat-ready-to-wear--HLC70WFK7502_PM2_Front view.png', 'louis-vuitton-tartan-check-extra-large-coat'),
(255, 11, 1, 'louis-vuitton-wrap-coat', 2300, 'louis-vuitton-wrap-coat', 'louis-vuitton-wrap-coat-ready-to-wear--HLC80EJZK002_PM2_Front view.jpg', 'louis-vuitton-wrap-coat'),

(255, 12, 1, 'louis-vuitton-monogram-jacquard-sweatshirt', 1000, 'louis-vuitton-monogram-jacquard-sweatshirt', 'louis-vuitton-monogram-jacquard-sweatshirt-highlights--HKY75WZRW900_PM2_Front view.jpg', 'louis-vuitton-monogram-jacquard-sweatshirt'),
(255, 12, 1, 'louis-vuitton-monogram-shearling-crewneck', 999, 'louis-vuitton-monogram-shearling-crewneck', 'louis-vuitton-monogram-shearling-crewneck-ready-to-wear--HHL77WRDA740_PM2_Front view.jpg', 'louis-vuitton-monogram-shearling-crewneck'),
(255, 12, 1, 'louis-vuitton-two-tone-high-neck-with-half-zip', 1020, 'louis-vuitton-two-tone-high-neck-with-half-zip', 'louis-vuitton-two-tone-high-neck-with-half-zip-ready-to-wear--HLN04WA54904_PM2_Front view.jpg', 'louis-vuitton-two-tone-high-neck-with-half-zip'),
(255, 12, 1, 'louis-vuitton-basket-weave-knitted-crewneck', 800, 'louis-vuitton-basket-weave-knitted-crewneck', 'louis-vuitton-basket-weave-knitted-crewneck-ready-to-wear--HIN10WTBB900_PM2_Front view.png', 'louis-vuitton-basket-weave-knitted-crewneck'),
(255, 12, 1, 'louis-vuitton-corduroy-shearling-cardigan', 980, 'louis-vuitton-corduroy-shearling-cardigan', 'louis-vuitton-corduroy-shearling-cardigan-ready-to-wear--HLL75WEQ6315_PM2_Front view.jpg', 'louis-vuitton-corduroy-shearling-cardigan'),
(255, 12, 1, 'louis-vuitton-louis-vuitton-2054-multi-logos-crewneck', 1040, 'louis-vuitton-louis-vuitton-2054-multi-logos-crewneck', 'louis-vuitton-louis-vuitton-2054-multi-logos-crewneck-ready-to-wear--HMN18WJL4MU1_PM2_Front view.jpg', 'louis-vuitton-louis-vuitton-2054-multi-logos-crewneck'),
(255, 12, 1, 'louis-vuitton-louis-vuitton-2054-patchwork-mock-neck', 870, 'louis-vuitton-louis-vuitton-2054-patchwork-mock-neck', 'louis-vuitton-louis-vuitton-2054-patchwork-mock-neck-ready-to-wear--HKN09WZLR900_PM2_Front view.jpg', 'louis-vuitton-louis-vuitton-2054-patchwork-mock-neck'),
(255, 12, 1, 'louis-vuitton-lvse-lv-embossed-turtle-neck', 800, 'louis-vuitton-lvse-lv-embossed-turtle', 'louis-vuitton-lvse-lv-embossed-turtle-neck-ready-to-wear--HMN41WJZE002_PM2_Front view.jpg', 'louis-vuitton-lvse-lv-embossed-turtle-neck'),
(255, 12, 1, 'louis-vuitton-mink-fur-sweater', 950, 'louis-vuitton-mink-fur-sweater', 'louis-vuitton-mink-fur-sweater-ready-to-wear--HLL91WGX6315_PM2_Front view.jpg', 'louis-vuitton-mink-fur-sweater'),
(255, 12, 1, 'louis-vuitton-monogram-fur-crewneck', 840, 'louis-vuitton-monogram-fur-crewneck', 'louis-vuitton-monogram-fur-crewneck-ready-to-wear--HJN93WYQQ900_PM2_Front view.jpg', 'louis-vuitton-monogram-fur-crewneck'),
(255, 12, 3, 'versace LA GRECA PRINT CHENILLE SWEATSHIRT', 830, 'LA GRECA PRINT CHENILLE SWEATSHIRT', 'LA GRECA PRINT CHENILLE SWEATSHIRT.jpg', 'LA GRECA PRINT CHENILLE SWEATSHIRT'),
(255, 12, 3, 'versace LOGO PRINT SWEATSHIRT', 799, 'LOGO PRINT SWEATSHIRT', 'LOGO PRINT SWEATSHIRT.jpg', 'LOGO PRINT SWEATSHIRT'),
(255, 12, 3, 'versace LOGO SHEARLING SWEATER', 810, 'LOGO SHEARLING SWEATER', 'LOGO SHEARLING SWEATER.jpg', 'LOGO SHEARLING SWEATER'),

(255, 13, 3, 'Versace-BAROCCO PRINT TRUNKS', 600, 'BAROCCO PRINT TRUNKS', 'BAROCCO PRINT TRUNKS.jpg', 'BAROCCO PRINT TRUNKs'),
(255, 13, 3, 'Versace-BAROCCO PRINT LOW RISE BRIEFS', 500, 'BAROCCO PRINT LOW RISE BRIEFS', 'BAROCCO PRINT LOW RISE BRIEFS.jpg', 'BAROCCO PRINT LOW RISE BRIEFS'),
(255, 13, 3, 'Versace LA GRECA PRINT BRIEFS', 550, 'LA GRECA PRINT BRIEFS', 'LA GRECA PRINT BRIEFS.jpg', 'LA GRECA PRINT BRIEFS'),
(255, 13, 3, 'versace LA GRECA PRINT TRUNKS', 400, 'LA GRECA PRINT TRUNKS', 'LA GRECA PRINT TRUNKS.jpg', 'LA GRECA PRINT TRUNKS'),
(255, 13, 3, 'LOGO LOW RISE TRUNKS BI-PACK', 450, 'LOGO LOW RISE TRUNKS BI-PACK', 'LOGO LOW RISE TRUNKS BI-PACK.jpg', 'LOGO LOW RISE TRUNKS BI-PACK'),
(255, 13, 3, 'versace GRECA BORDER TRUNKS', 520, 'versace GRECA BORDER TRUNKS', 'versace GRECA BORDER TRUNKS.jpg', 'versace GRECA BORDER TRUNKS'),
(255, 13, 3, 'medusa motif jockstrap', 499, 'medusa motif jockstrap', 'medusa motif jockstrap.jpg', 'medusa motif jockstrap'),
(255, 13, 2, 'premium_mens_gucci_boxer', 399, 'premium_mens_gucci_boxer', 'premium_mens_gucci_boxer_under_1592293505_26dae3f1_progressive.jpg', 'premium_mens_gucci_boxer'),
(255, 13, 2, 'Gucci boxer', 370, 'gucci_boxer', 'rBVaVFxgTqmAAXbDAABWGp2qIXo863.jpg', 'gucci boxer'),
(255, 13, 2, 'Gucci boxer Border Trunks', 340, 'boxer', '698e7f2ddeb61121c33d6de91959a887.jpg_360x360q90.jpg_.jpg', 'boxer'),
(255, 13, 4, 'calvin-klein-red-boxer-brief', 400, 'calvin-klein-red-boxer', '5fa9b8f49d17714002fba1049aea7b31ca-calvin-klein-red-boxer-brief.2x.rsquare.w600.jpg', 'calvin-klein-red-boxer'),
(255, 13, 6, 'Adidas blue boxer', 440, 'boxer', '86c7cb379b12138b5c846c5894e84460.jpg', 'boxer'),
(255, 13, 4, 'CK white border Trunks', 370, 'boxer', 'image-1022-124000385-1-big-hr.jpg', 'boxer'),
(255, 13, 4, 'ck border Rainbow Trunks', 300, 'boxer', '2566693.jpg', 'boxer'),
(255, 13, 4, 'ck grey boxer', 390, 'boxer', '-473Wx593H-460741993-grey-MODEL.jpg', 'boxer'),
(255, 13, 5, 'Champion blue and red-line-boxer', 320, 'boxer', '44024.jpg', 'boxer'),
(255, 13, 5, 'champion script logo print', 400, 'boxer', '52145.jpg', 'boxer'),
(255, 13, 5, 'champion red logo print', 330, 'boxer', '79684.jpg', 'boxer'),
(255, 13, 5, 'champion white logo script print Trunks', 310, 'boxer', 'resize.jpg', 'boxer'),
(255, 13, 1, 'louis-vuitton-logo print boxer', 380, 'boxer', 'cc6159a08e5d9b04d5fe9d77cf1aa726.jpg', 'boxer'),
(255, 13, 1, 'louis-vuitton-graphic-script-print', 360, 'boxer', 'org.jpg', 'boxer'),
(255, 13, 3, 'Under shirt Bi-Pack-Tanks-versace', 300, 'Undershirt', '90_AU10193-A232741_A1001_10_UndershirtBi-Pack-Tanks-versace-online-store_0_2.jpg', 'UndershirtBi-Pack-Tanks-versace'),
(255, 13, 3, 'GVSignatureTankTop-Pajamas-versace', 280, 'GVSignatureTankTop-Pajamas-versace', '90_AUU81002-A233274_A1001_10_GVSignatureTankTop-Pajamas-versace-online-store_4_2.jpg', 'GVSignatureTankTop-Pajamas-versace'),
(255, 13, 3, 'Barocco Print Undershirt-Tanks-versace', 300, 'Undershirt', '90_1000959-1A00515_5B000_10_BaroccoPrintUndershirt-Tanks-versace-online-store_0_1.jpg', 'BaroccoPrintUndershirt-Tanks-versace'),
(255, 13, 5, 'champion Undershirt', 310, 'boxer', '8131607_default_1.jpg', 'boxer'),
(255, 13, 2, 'gucci Undershirt', 320, 'boxer', '80672975bcbc57bf3f898d9e903a38a5.jpg', 'gucci'),
(255, 13, 5, 'champion-city-mesh-tank-top-white', 250, 'champion-city-mesh-tank-top-white', 'champion-city-mesh-tank-top-white-back_1200x1200.jpg', 'champion-city-mesh-tank-top-white'),
(255, 13, 3, 'versace MEDUSA LOGO UNDERSHIRT', 300, 'MEDUSA LOGO UNDERSHIRT', 'MEDUSA LOGO UNDERSHIRT.jpg', 'MEDUSA LOGO UNDERSHIRT');








-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(12, 'binil', 'vincent', 'binilvincent00@gmail.com', 'bvthz00', '+1 7902554500', '4522 Confederate Drive', 'Hartsdale, NewYork'),
(15, 'felbin', 'john', 'felbinjohn00@gmail.com', 'fjnyc00', '+1 9645675900', '1330 Hinkle Deegan Lake Road', 'Liverpool, NewYork'),
(16, 'asish', 'jolly', 'asishjolly00@gmail.com', 'ajbts00', '+1 9847136700', '2400 Geneva Street', 'NewYork, NewYork');


--
-- Triggers `user_info`
--
DELIMITER $$
CREATE TRIGGER `after_user_info_insert` AFTER INSERT ON `user_info` FOR EACH ROW BEGIN 
INSERT INTO user_info_backup VALUES(new.user_id,new.first_name,new.last_name,new.email,new.password,new.mobile,new.address1,new.address2);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_info_backup`
--

CREATE TABLE `user_info_backup` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info_backup`
--

INSERT INTO `user_info_backup` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(12, 'binil', 'vincent', 'binilvincent00@gmail.com', 'bvthz00', '+1 7902554500', '4522 Confederate Drive', 'Hartsdale, NewYork'),
(15, 'felbin', 'john', 'felbinjohn00@gmail.com', 'fjnyc00', '+1 9645675900', '1330 Hinkle Deegan Lake Road', 'Liverpool, NewYork'),
(16, 'asish', 'jolly', 'asishjolly00@gmail.com', 'ajbts00', '+1 9847136700', '2400 Geneva Street', 'NewYork, NewYork');


--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_info`
--
ALTER TABLE `admin_info`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `email_info`
--
ALTER TABLE `email_info`
  ADD PRIMARY KEY (`email_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`order_pro_id`),
  ADD KEY `order_products` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_info_backup`
--
ALTER TABLE `user_info_backup`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_info`
--
ALTER TABLE `admin_info`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `email_info`
--
ALTER TABLE `email_info`
  MODIFY `email_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders_info`
--
ALTER TABLE `orders_info`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `order_pro_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `user_info_backup`
--
ALTER TABLE `user_info_backup`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`);

--
-- Constraints for table `order_products`
--
ALTER TABLE `order_products`
  ADD CONSTRAINT `order_products` FOREIGN KEY (`order_id`) REFERENCES `orders_info` (`order_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
